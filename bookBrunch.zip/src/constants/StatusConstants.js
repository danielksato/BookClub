// @flow
export const INITIAL = 'INITIAL';
export const IN_PROGRESS = 'IN_PROGRESS';
export const DONE = 'DONE';
export const ERROR = 'ERROR';
