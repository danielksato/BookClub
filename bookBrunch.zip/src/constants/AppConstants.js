// @flow
export const PROPOSED = 'proposed';
export const ACTIVE = 'active';
export const ARCHIVED = 'archived';

export const INVITED = 'invited';
export const MEMBER = 'member';
export const ADMIN = 'admin';
