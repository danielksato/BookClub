// @flow
export default function(e: SyntheticEvent<HTMLElement>) {
	e.preventDefault();
}
