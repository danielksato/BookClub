// @flow
export default function() {
	return {
		firstName: 'Daniel',
		lastName: 'Sato',
		email: 'dksato@gmail.com',
		id: 1,
		clubs: [1],
	};
}
